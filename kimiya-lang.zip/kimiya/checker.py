"""Static checker: the paper's disciplines as rejection rules.

  K1  judged relations must cite a declared purpose
  K2  a retry's judge panel must be cross-provenance from the body's
      generator (J-not-lhd-C)
  K3  select recall must lie in (0, 1]
  K4  an irreversible act may not occur inside a retry body
  K5  an irreversible act must be gated (verified gate)
  K6  world-touching retry needs inv/compensate (snapshot retry over an
      external world is unsound)
  K7  gen schemas must be declared (or builtin Text/Json)
  K8  names defined before use; functions called at declared arity;
      function bodies see only their parameters and other functions
  K9  retry budgets and settle deadlines positive; return only inside fn
"""

from __future__ import annotations

from . import ast_nodes as A
from . import dom
from . import screen
from .runtime import Agent, family_of, PARAM_TYPES

BUILTIN_SCHEMAS = {"Text", "Json"}
BUILTIN_FUNCS = {
    "len", "contains", "starts_with", "lower", "trim", "lines", "join",
    "str", "num", "hash", "now", "range", "first", "last", "keys",
    "file_exists", "dom_stable", "map", "filter", "sort_by", "sum",
}
DEFAULT_IRREVERSIBLE = {("file", "overwrite"), ("file", "delete")} | \
    {("screen", a) for a in screen.IRREVERSIBLE} | \
    {("dom", a) for a in dom.IRREVERSIBLE}
KNOWN_ACTIONS = {("file", "create"), ("file", "append"),
                 ("file", "overwrite"), ("file", "delete"),
                 ("file", "mkdir")} | \
    {("screen", a) for a in screen.ACTIONS} | \
    {("dom", a) for a in dom.ACTIONS}
# action -> arity, for the surfaces that fix one. `file` actions vary
# (mkdir takes 1, append takes 2), so `screen` and `dom` are pinned here.
ACTION_ARITY = {("screen", a): n for a, n in screen.ACTIONS.items()} | \
    {("dom", a): n for a, n in dom.ACTIONS.items()}
KNOWN_SURFACES = {"file", "screen", "dom"}
OBSERVE_SURFACES = {"file", "screen", "image", "dom", "view"}


def _substmts(s) -> list[list]:
    if isinstance(s, A.IfStmt):
        return [s.then] + ([s.els] if s.els else [])
    if isinstance(s, A.ForallStmt):
        return [s.body]
    if isinstance(s, A.ExploreStmt):
        return [s.body]
    if isinstance(s, A.RetryStmt):
        return [s.body] + ([s.compensate] if s.compensate else [])
    if isinstance(s, A.Assign) and isinstance(s.rhs, A.RetryStmt):
        return _substmts(s.rhs)
    return []


class CheckReport:
    def __init__(self):
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def err(self, line: int, msg: str):
        self.errors.append(f"line {line}: error: {msg}")

    def warn(self, line: int, msg: str):
        self.warnings.append(f"line {line}: warning: {msg}")

    @property
    def ok(self) -> bool:
        return not self.errors


def check(prog: A.Program, py_fn_names=frozenset()) -> CheckReport:
    r = CheckReport()
    pools = {d.name: d.model for d in prog.decls
             if isinstance(d, A.PoolDecl)}
    can_see = {d.name: Agent(name=d.name, model=d.model).vision
               for d in prog.decls if isinstance(d, A.PoolDecl)}
    for d in prog.decls:
        if isinstance(d, A.AgentDecl):
            fk = d.fields
            backend = fk.get("backend", "ollama")
            if backend not in ("ollama", "openai", "openrouter",
                               "anthropic", "claude_cli"):
                r.err(d.line, f"agent '{d.name}': unknown backend "
                              f"'{backend}'")
            if "model" not in fk:
                r.err(d.line, f"agent '{d.name}': missing model")
            if backend in ("anthropic", "claude_cli") and fk.get("url"):
                r.warn(d.line, f"agent '{d.name}': 'url' is ignored on the "
                               f"{backend} backend")
            if backend == "openrouter" and not (
                    "key_env" in fk or "key_file" in fk):
                r.warn(d.line, f"agent '{d.name}': openrouter without "
                               "key_env/key_file — declare a credential source")
            if "key_env" in fk and "key_file" in fk:
                r.err(d.line, f"agent '{d.name}': choose key_env or key_file, "
                              "not both")
            if "zdr" in fk and backend != "openrouter":
                r.warn(d.line, f"agent '{d.name}': 'zdr' is only used by "
                               "the openrouter backend")
            if backend == "openai" and "url" not in fk:
                r.err(d.line, f"agent '{d.name}': openai backend needs a "
                              "url (the pod's /v1 endpoint)")
            # family_of over the model, respecting a family override
            fam = fk.get("family") or family_of(fk.get("model", ""))
            pools[d.name] = "override://" + fam if fk.get("family") \
                else fk.get("model", "")
            can_see[d.name] = Agent(
                name=d.name, model=fk.get("model", ""),
                vision_declared=fk.get("vision")).vision
    params: dict[str, A.ParamDecl] = {}
    for d in prog.decls:
        if not isinstance(d, A.ParamDecl):
            continue
        if d.name in params:
            r.err(d.line, f"duplicate param '{d.name}' (first declared on "
                          f"line {params[d.name].line})")
            continue
        params[d.name] = d
        if d.type not in PARAM_TYPES:
            r.err(d.line, f"param '{d.name}': unknown type '{d.type}' "
                          f"(known: {', '.join(PARAM_TYPES)})")
        elif d.type == "secret":
            if not d.required:
                r.err(d.line, f"param '{d.name}': secret params cannot "
                              "have a default — a literal secret in source "
                              "is disclosed to every reader. Pass it at "
                              f"run time ({d.name}=<value> or "
                              f"{d.name}=env:VAR)")
        elif not d.required:
            want = {"text": str, "num": float, "bool": bool}[d.type]
            if d.type == "num" and isinstance(d.default, bool):
                r.err(d.line, f"param '{d.name}': default is not a number")
            elif not isinstance(d.default, want):
                r.err(d.line, f"param '{d.name}': default "
                              f"{d.default!r} is not a {d.type}")

    displays = {d.name for d in prog.decls if isinstance(d, A.DisplayDecl)}
    for d in prog.decls:
        if isinstance(d, A.DisplayDecl):
            for k in d.fields:
                if k not in ("x11", "ssh", "monitor"):
                    r.err(d.line, f"display '{d.name}': unknown field "
                                  f"'{k}' (known: x11, ssh, monitor)")

    def chk_actor(actor, line, what):
        """K13: an actor index must name a declared display."""
        if actor is not None and actor not in displays:
            r.err(line, f"{what}<{actor}>: '{actor}' is not a declared "
                        "display — declare it with `display "
                        f"{actor}:` (x11 / ssh / monitor)")

    contexts = {d.name for d in prog.decls if isinstance(d, A.ContextDecl)}
    schemas = ({d.name for d in prog.decls if isinstance(d, A.SchemaDecl)}
               | BUILTIN_SCHEMAS)
    fns = {d.name: d for d in prog.decls if isinstance(d, A.FnDecl)}
    pyfns = set(py_fn_names) | {d.name for d in prog.decls
                                if isinstance(d, A.PyFnDecl)}
    irreversible = set(DEFAULT_IRREVERSIBLE)
    for d in prog.decls:
        if isinstance(d, A.EffectDecl):
            if d.klass == "irreversible":
                irreversible.add((d.surface, d.action))
            else:
                irreversible.discard((d.surface, d.action))

    defined: set[str] = set(params)
    in_fn = [False]

    def known_callable(name: str) -> bool:
        return (name in BUILTIN_FUNCS or name in fns or name in pyfns
                or name in defined)

    # ---------- expressions ----------
    def chk_expr(e):
        if isinstance(e, A.Var):
            if not (e.name in defined or e.name in fns or e.name in pyfns
                    or e.name in BUILTIN_FUNCS):
                r.err(e.line, f"undefined name '{e.name}'")
        elif isinstance(e, A.Call):
            if not known_callable(e.func):
                r.err(e.line, f"unknown function '{e.func}'")
            if e.func in fns and len(e.args) != len(fns[e.func].params):
                r.err(e.line,
                      f"'{e.func}' takes {len(fns[e.func].params)} "
                      f"argument(s), got {len(e.args)}")
            for a in e.args:
                chk_expr(a)
        elif isinstance(e, A.BinOp):
            chk_expr(e.left)
            chk_expr(e.right)
        elif isinstance(e, A.UnOp):
            chk_expr(e.operand)
        elif isinstance(e, A.Field):
            chk_expr(e.obj)
        elif isinstance(e, A.Index):
            chk_expr(e.obj)
            chk_expr(e.index)
        elif isinstance(e, A.InterpString):
            for x in e.exprs:
                chk_expr(x)
        elif isinstance(e, A.ListExpr):
            for x in e.items:
                chk_expr(x)
        elif isinstance(e, A.RecordExpr):
            for _, x in e.fields:
                chk_expr(x)
        elif isinstance(e, A.ObserveExpr):
            if e.surface not in OBSERVE_SURFACES:
                r.err(e.line, f"unknown observe surface '{e.surface}' "
                              f"(known: {', '.join(sorted(OBSERVE_SURFACES))})")
            if e.actor is not None and e.surface != "screen":
                r.err(e.line, "an actor index applies to the screen "
                              f"surface only — observe {e.surface}<"
                              f"{e.actor}> has no meaning")
            chk_actor(e.actor, e.line, f"observe {e.surface}")
            if e.surface == "image" and len(e.args) != 1:
                r.err(e.line, "observe image(...) takes exactly one path")
            if e.surface == "dom" and len(e.args) > 1:
                r.err(e.line, "observe dom(...) takes at most one "
                              "selector")
            if e.surface == "view" and e.args:
                r.err(e.line, "observe view() takes no arguments — it "
                              "captures the host's one bound webview")
            for a in e.args:
                chk_expr(a)

    # ---------- guards ----------
    def chk_guard(g, generator_model):
        if isinstance(g, A.CheckGuard):
            chk_expr(g.expr)
            return
        if g.context not in contexts:
            r.err(g.line, f"judge cites undeclared purpose '{g.context}' "
                          "(a judged relation without a declared purpose "
                          "is ill-formed)")
        if not 0 < g.tau <= 1:
            r.err(g.line, f"threshold {g.tau} outside (0,1]")
        if g.panel:
            for p in g.panel:
                if p not in pools:
                    r.err(g.line,
                          f"panel member '{p}' is not a declared pool")
        if generator_model:
            gf = family_of(generator_model)
            cand = ([pools[p] for p in (g.panel or []) if p in pools]
                    if g.panel else list(pools.values()))
            cand = [m for m in cand if m != generator_model] or cand
            if cand and all(family_of(m) == gf for m in cand):
                r.err(g.line,
                      "J ⋪ C violated: every available panel model shares "
                      f"the generator's family '{gf}' — self-judgment "
                      "never certifies (add a pool from another family)")
        chk_expr(g.left)
        if g.right is not None:
            chk_expr(g.right)
        chk_shows(g)

    # ---------- the vision instrument (K10-K12) ----------
    # A screen store turns `select` from a mechanical filter into a
    # measured instrument, so it acquires the obligations a judged step
    # has: name the instrument, state the purpose it reads under, and use
    # something that can actually see.
    screenshots: set[str] = set()
    images: set[str] = set()
    dom_snaps: set[str] = set()
    views: set[str] = set()

    def is_screenshot(e) -> bool:
        if isinstance(e, A.ObserveExpr):
            return e.surface == "screen"
        return isinstance(e, A.Var) and e.name in screenshots

    def is_image(e) -> bool:
        if isinstance(e, A.ObserveExpr):
            return e.surface == "image"
        return isinstance(e, A.Var) and e.name in images

    def is_dom(e) -> bool:
        if isinstance(e, A.ObserveExpr):
            return e.surface == "dom"
        return isinstance(e, A.Var) and e.name in dom_snaps

    def is_view(e) -> bool:
        if isinstance(e, A.ObserveExpr):
            return e.surface == "view"
        return isinstance(e, A.Var) and e.name in views

    def chk_vision_select(sel: A.SelectExpr):
        if is_dom(sel.store):
            # A DOM select is a model reading candidate elements — an
            # instrument, like the screen locate, though it needs no
            # eyes: the snapshot is text.
            if not sel.by:
                r.err(sel.line,
                      "select over a dom snapshot needs an instrument: "
                      "add `by <agent>`. Picking an element is a model "
                      "reading the page, and the certificate must name "
                      "what read it")
            elif sel.by not in pools:
                r.err(sel.line, f"'by {sel.by}': not a declared pool")
            if not sel.context:
                r.err(sel.line,
                      "select over a dom snapshot must cite a purpose "
                      "(`under <context>`) — it is a judged reading, and "
                      "its datasheet is keyed by that purpose "
                      "(dom_locate:<context>)")
            return
        if not is_screenshot(sel.store):
            if sel.by:
                r.warn(sel.line,
                       f"'by {sel.by}' on a select over a non-screen store "
                       "has no effect — text select is a mechanical filter, "
                       "no model is consulted")
            if not sel.context:
                r.warn(sel.line,
                       "select is a retrieval instrument; without `under "
                       "<purpose>` its factor lands at select:unscoped "
                       "(prior grade) — declare a purpose to key a "
                       "measured datasheet")
            return
        if not sel.by:
            r.err(sel.line,
                  "select over a screenshot needs an instrument: add "
                  "`by <agent>`. Localizing a control is a model reading "
                  "an image, and the certificate must name what read it")
        elif sel.by not in pools:
            r.err(sel.line, f"'by {sel.by}': not a declared pool")
        elif not can_see[sel.by]:
            r.err(sel.line,
                  f"'by {sel.by}': {pools[sel.by]} is not vision-capable — "
                  "it would answer about a screenshot it never saw. "
                  "Declare `vision = true` on the agent if it can see")
        if not sel.context:
            r.err(sel.line,
                  "select over a screenshot must cite a purpose (`under "
                  "<context>`) — it is a judged reading, and its datasheet "
                  "is keyed by that purpose")

    def chk_shows(g: A.JudgeGuard):
        if g.relation != "shows":
            return
        if not (is_screenshot(g.left) or is_image(g.left)
                or is_view(g.left)):
            r.err(g.line,
                  "shows(...) takes an observed image as its first "
                  "argument (from `observe screen(...)`, "
                  "`observe image(...)` or `observe view()`)")
        blind = [p for p in (g.panel or list(pools))
                 if p in can_see and not can_see[p]]
        if blind:
            r.err(g.line,
                  f"shows(...) panel member(s) {', '.join(blind)} are not "
                  "vision-capable — they would vote on an image they never "
                  "saw. Declare `vision = true`, or panel only on "
                  "agents that can see")

    # ---------- statements ----------
    def body_generator(stmts):
        for s in stmts:
            if isinstance(s, A.Assign) and isinstance(s.rhs, A.GenExpr):
                if s.rhs.by:
                    return pools.get(s.rhs.by)
                return next(iter(pools.values()), None)
        return None

    def contains_act(stmts) -> bool:
        for s in stmts:
            if isinstance(s, A.ActStmt):
                return True
            if any(contains_act(sub) for sub in _substmts(s)):
                return True
        return False

    def gated(prev, s) -> bool:
        return (isinstance(prev, A.CheckStmt)
                or getattr(s, "gated_by_if", False))

    def chk_stmts(stmts, in_retry: bool):
        prev = None
        for s in stmts:
            chk_stmt(s, in_retry, prev)
            prev = s

    def chk_stmt(s, in_retry: bool, prev):
        if isinstance(s, A.Assign):
            rhs = s.rhs
            if isinstance(rhs, A.GenExpr):
                if rhs.schema not in schemas:
                    r.err(rhs.line,
                          f"gen cites undeclared schema '{rhs.schema}'")
                if rhs.by and rhs.by not in pools:
                    r.err(rhs.line, f"'by {rhs.by}': not a declared pool")
                if rhs.context and rhs.context not in contexts:
                    r.err(rhs.line, f"gen cites undeclared purpose "
                                    f"'{rhs.context}'")
                if rhs.context and rhs.images is None:
                    r.warn(rhs.line,
                           "`under` on a text-only gen has no effect — "
                           "only image reads are priced")
                if rhs.images is not None and not rhs.context:
                    r.warn(rhs.line,
                           "gen with images is a priced read; without "
                           "`under <purpose>` its factor lands at "
                           "read:unscoped (prior grade) — declare a "
                           "purpose to use a measured datasheet")
                chk_expr(rhs.prompt)
                if rhs.images is not None:
                    chk_expr(rhs.images)
                    gen_name = rhs.by or next(iter(pools), None)
                    if gen_name in can_see and not can_see[gen_name]:
                        r.err(rhs.line,
                              f"'by {gen_name}': {pools[gen_name]} is not "
                              "vision-capable — multimodal gen would ask it "
                              "about images it cannot see. Declare "
                              "`vision = true` if it can see")
            elif isinstance(rhs, A.SelectExpr):
                if not 0 < rhs.recall <= 1:
                    r.err(rhs.line,
                          f"select recall {rhs.recall} outside (0,1] — a "
                          "coverage claim needs a stated recall")
                if rhs.context and rhs.context not in contexts:
                    r.err(rhs.line, f"select cites undeclared purpose "
                                    f"'{rhs.context}'")
                chk_expr(rhs.query)
                chk_expr(rhs.store)
                chk_vision_select(rhs)
            elif isinstance(rhs, A.RetryStmt):
                chk_retry(rhs)
            else:
                chk_expr(rhs)
            defined.add(s.name)
            if is_screenshot(rhs):
                screenshots.add(s.name)
            else:
                screenshots.discard(s.name)
            if is_image(rhs):
                images.add(s.name)
            else:
                images.discard(s.name)
            if is_dom(rhs):
                dom_snaps.add(s.name)
            else:
                dom_snaps.discard(s.name)
            if is_view(rhs):
                views.add(s.name)
            else:
                views.discard(s.name)
        elif isinstance(s, (A.CheckStmt, A.PrintStmt, A.CommitStmt)):
            chk_expr(s.expr)
        elif isinstance(s, A.AbstainStmt):
            pass
        elif isinstance(s, A.ReturnStmt):
            if not in_fn[0]:
                r.err(s.line, "return outside a function")
            if s.expr is not None:
                chk_expr(s.expr)
        elif isinstance(s, A.IfStmt):
            chk_guard(s.guard, None)
            for branch in (s.then, s.els or []):
                if branch and isinstance(branch[0], A.ActStmt):
                    branch[0].gated_by_if = True
            chk_stmts(s.then, in_retry)
            if s.els:
                chk_stmts(s.els, in_retry)
        elif isinstance(s, A.ForallStmt):
            chk_expr(s.iterable)
            defined.add(s.var)
            chk_stmts(s.body, in_retry)
        elif isinstance(s, A.RetryStmt):
            chk_retry(s)
        elif isinstance(s, A.ActStmt):
            key = (s.surface, s.action)
            if s.actor is not None and s.surface != "screen":
                r.err(s.line, "an actor index applies to the screen "
                              f"surface only — act<{s.actor}> "
                              f"{s.surface}.{s.action} has no meaning")
            chk_actor(s.actor, s.line, "act")
            if s.surface not in KNOWN_SURFACES:
                r.err(s.line, f"unknown act surface '{s.surface}' "
                              f"(known: {', '.join(sorted(KNOWN_SURFACES))})")
            elif key not in KNOWN_ACTIONS and key not in irreversible:
                r.err(s.line, f"unknown action {s.surface}.{s.action}")
            elif key in ACTION_ARITY and len(s.args) != ACTION_ARITY[key]:
                r.err(s.line,
                      f"{s.surface}.{s.action} takes "
                      f"{ACTION_ARITY[key]} argument(s), "
                      f"got {len(s.args)}")
            for a in s.args:
                chk_expr(a)
            if key in irreversible:
                if in_retry:
                    r.err(s.line,
                          f"irreversible act {s.surface}.{s.action} inside "
                          "a retry body (forbidden: retry may re-fire it)")
                elif not gated(prev, s):
                    r.err(s.line,
                          f"irreversible act {s.surface}.{s.action} is "
                          "unguarded — precede it with a check, or place "
                          "it first in a checked/judged if-branch (the "
                          "verified gate)")
        elif isinstance(s, A.ExploreStmt):
            chk_explore(s)
        elif isinstance(s, A.SettleStmt):
            chk_actor(s.actor, s.line, "settle")
            chk_guard(s.guard, None)
            if s.within <= 0:
                r.err(s.line, "settle deadline must be positive")

    def chk_explore(s: A.ExploreStmt):
        """K14: exploration is free precisely because it carries no
        authority — so nothing inside may commit, and nothing inside may
        change the world irreversibly. A verdict cannot rest on
        unaccounted judgments."""
        def walk(stmts):
            for st in stmts:
                if isinstance(st, A.CommitStmt):
                    r.err(st.line,
                          "commit inside explore — exploration's judged "
                          "factors are excluded from θ, so a verdict here "
                          "would rest on unaccounted judgments; commit "
                          "outside the explore block, behind live gates")
                if isinstance(st, A.ActStmt):
                    key = (st.surface, st.action)
                    if key in irreversible:
                        r.err(st.line,
                              f"irreversible act {st.surface}.{st.action} "
                              "inside explore — an unaccounted judgment "
                              "must not justify an effect that cannot be "
                              "taken back")
                for sub in _substmts(st):
                    walk(sub)
        walk(s.body)
        chk_stmts(s.body, in_retry=False)

    def chk_retry(s: A.RetryStmt):
        if s.budget <= 0:
            r.err(s.line, "retry budget must be positive")
        gen_model = body_generator(s.body)
        chk_stmts(s.body, in_retry=True)
        chk_guard(s.guard, gen_model)
        if contains_act(s.body) and s.inv is None and s.compensate is None:
            r.err(s.line,
                  "retry body performs world effects but declares neither "
                  "inv nor compensate — snapshot retry over an external "
                  "world is unsound (world-frame retry required)")
        if s.inv is not None:
            chk_expr(s.inv)
        if s.compensate:
            chk_stmts(s.compensate, in_retry=False)

    # ---------- function bodies: own scope, no globals ----------
    for f in fns.values():
        saved = set(defined)
        defined.clear()
        defined.update(f.params)
        in_fn[0] = True
        chk_stmts(f.body, in_retry=False)
        in_fn[0] = False
        defined.clear()
        defined.update(saved)

    if not pools:
        has_model_step = any(
            isinstance(s, A.Assign)
            and isinstance(s.rhs, (A.GenExpr, A.SelectExpr, A.RetryStmt))
            for s in prog.body)
        if has_model_step:
            r.warn(0, "no pool declared: gen/select/judge will fail at "
                      "runtime")
    chk_stmts(prog.body, in_retry=False)
    return r
