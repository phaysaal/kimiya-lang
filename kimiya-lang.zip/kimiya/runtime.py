"""Local-model runtime for the Kimiya interpreter.

The single network touchpoint of the interpreter: 127.0.0.1 only (port via
KIMIYA_OLLAMA_PORT). Judge panels enforce J-not-lhd-C; datasheets carry
conservative Wilson ends from locally collected labels; every judgment and
generation appends to an append-only trace.
"""

from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

ALLOWED_HOST = "127.0.0.1"   # loopback only, never configurable
ALLOWED_PORT = int(os.environ.get("KIMIYA_OLLAMA_PORT", "11434"))
BASE_URL = f"http://{ALLOWED_HOST}:{ALLOWED_PORT}"

# Models that can read an image. Used to reject, at check time, a vision
# instrument pointed at a text-only model — the failure mode otherwise is
# a confident answer about an image the model never saw.
VISION_PATTERNS = [
    "llava", "vision", "-vl", "pixtral", "minicpm-v", "moondream",
    "gemma3", "internvl", "multimodal", "bakllava", "granite3.2-vision",
    "gpt-4o", "gpt-4.1", "gpt-5", "claude", "gemini", "qwen3-vl",
    "mistral-small3", "nova-lite", "nova-pro", "grok-vision",
]

FAMILY_PATTERNS = [
    ("llama", "llama"), ("qwen", "qwen"), ("mistral", "mistral"),
    ("mixtral", "mistral"), ("gemma", "gemma"), ("phi", "phi"),
    ("deepseek", "deepseek"), ("granite", "granite"),
    ("command-r", "cohere"), ("olmo", "olmo"), ("smollm", "smollm"),
    ("claude", "anthropic"), ("gpt", "openai"), ("o3", "openai"),
    ("grok", "xai"), ("nova", "amazon"),
]
PROVIDER_FAMILIES = {
    "anthropic": "anthropic", "openai": "openai", "google": "google",
    "meta-llama": "llama", "mistralai": "mistral", "qwen": "qwen",
    "deepseek": "deepseek", "x-ai": "xai", "cohere": "cohere",
    "amazon": "amazon", "microsoft": "phi",
}


def family_of(model: str) -> str:
    m = model.lower()
    if m.startswith("override://"):   # a declared family override
        return m.split("://", 1)[1]
    if "/" in m:                      # openrouter-style provider/model
        provider = m.split("/", 1)[0]
        if provider in PROVIDER_FAMILIES:
            return PROVIDER_FAMILIES[provider]
    for pat, fam in FAMILY_PATTERNS:
        if pat in m:
            return fam
    return m.split("/")[-1].split(":")[0]


@dataclass
class Agent:
    """A declared model instance: who it is, where it runs, its family.

    Backends: "ollama" (default; local unless url says otherwise),
    "openai" (any OpenAI-compatible /v1 endpoint — vLLM on a vast.ai pod,
    llama.cpp server, LM Studio), "openrouter". API keys never appear in
    source; key_env names an environment variable and key_file names a
    runtime-only credential file.
    """

    name: str
    model: str
    backend: str = "ollama"
    url: str | None = None
    key_env: str | None = None
    key_file: str | None = None
    zdr: bool = False
    family_override: str | None = None
    vision_declared: bool | None = None

    @property
    def family(self) -> str:
        return self.family_override or family_of(self.model)

    @property
    def vision(self) -> bool:
        """Can this agent read an image? Declared wins over inferred."""
        if self.vision_declared is not None:
            return self.vision_declared
        if os.environ.get("KIMIYA_MOCK") == "1":
            return True
        m = self.model.lower()
        return any(p in m for p in VISION_PATTERNS)

    @property
    def resolved_url(self) -> str:
        if self.url:
            return self.url.rstrip("/")
        if self.backend == "openrouter":
            return "https://openrouter.ai/api/v1"
        if self.backend in ("anthropic", "claude_cli"):
            return "https://api.anthropic.com"
        return BASE_URL

    @property
    def host(self) -> str:
        u = self.resolved_url
        host = u.split("//", 1)[-1].split("/", 1)[0]
        if self.backend == "claude_cli":
            # The prompt leaves the machine through the CLI rather than
            # through this process's socket — same egress either way, and
            # the certificate must say so.
            return host + " (via claude CLI)"
        return host

    @property
    def is_local(self) -> bool:
        if self.backend in ("anthropic", "claude_cli"):
            return False
        return self.host.split(":")[0] in ("127.0.0.1", "localhost")

    def label(self) -> str:
        where = "local" if self.is_local else self.host
        return f"{self.name}={self.model}@{where}"


def _wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = (z / denom) * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (max(0.0, centre - half), min(1.0, centre + half))


PRIOR_SHEET = {"alpha_hi": 0.25, "beta_lo": 0.60,
               "n_true": 0, "n_false": 0, "calibrated": False}


class ProviderRefusal(RuntimeError):
    """The provider rejected the account itself, not one request.

    Authentication failures and exhausted credit do not heal with
    retries; every further attempt burns time and, once credit
    returns, money. The run must stop and say why.
    """


class Datasheets:
    def __init__(self, workspace: Path):
        self.workspace = Path(workspace)
        self.labels_path = self.workspace / "labels.jsonl"
        self.local_path = self.workspace / "datasheets.json"
        self._sheets: dict[str, dict] = {}
        if self.local_path.exists():
            self._sheets = json.loads(self.local_path.read_text())

    def get(self, task: str) -> dict:
        return dict(self._sheets.get(task, PRIOR_SHEET))

    def install(self, task: str, sheet: dict):
        """Record an instrument measured elsewhere.

        Calibration from this workspace's own labels is the normal path.
        But an instrument may have been measured by a separate campaign —
        a harness that ran it hundreds of times against known ground
        truth — and re-deriving that here would be busywork. Such a sheet
        carries its `source` into every certificate that uses it, so a
        reviewer can see the numbers were imported and from where.
        """
        self._sheets[task] = dict(sheet)
        self.local_path.write_text(json.dumps(self._sheets, indent=2))

    def add_label(self, task: str, truth: bool, verdict: bool):
        with self.labels_path.open("a") as f:
            f.write(json.dumps({"task": task, "truth": truth,
                                "verdict": verdict, "ts": time.time()}) + "\n")

    def recompute(self):
        by: dict[str, dict] = {}
        if self.labels_path.exists():
            for line in self.labels_path.read_text().splitlines():
                if not line.strip():
                    continue
                r = json.loads(line)
                t = by.setdefault(r["task"], {"tp": 0, "n_true": 0,
                                              "fp": 0, "n_false": 0})
                if r["truth"]:
                    t["n_true"] += 1
                    t["tp"] += int(r["verdict"])
                else:
                    t["n_false"] += 1
                    t["fp"] += int(r["verdict"])
        for task, c in by.items():
            self._sheets[task] = {
                "alpha_hi": _wilson(c["fp"], c["n_false"])[1],
                "beta_lo": _wilson(c["tp"], c["n_true"])[0],
                "n_true": c["n_true"], "n_false": c["n_false"],
                "calibrated": c["n_true"] >= 10 and c["n_false"] >= 10,
            }
        self.local_path.write_text(json.dumps(self._sheets, indent=2))
        return self._sheets


class MemoStore:
    """Exact-input reuse of instrument readings (`memo gen` / `memo judge`).

    A memoized reading is the same epistemics as the locate cache's
    exact-SHA hit: identical input, identical reading. Reuse is free in
    cost and — for judgments — its θ factor is counted ONCE per run, at
    the reading's first use on the verdict path. Persisted per workspace,
    keyed by a hash of everything that could change the answer.
    """

    def __init__(self, workspace: Path):
        self.path = Path(workspace) / "memo.json"
        self._d: dict = {}
        if self.path.exists():
            try:
                self._d = json.loads(self.path.read_text())
            except (json.JSONDecodeError, OSError):
                self._d = {}

    @staticmethod
    def key(kind: str, *parts) -> str:
        return kind + ":" + h("\x1f".join(str(p) for p in parts))

    def get(self, k: str):
        return self._d.get(k)

    def put(self, k: str, entry: dict):
        self._d[k] = dict(entry, ts=time.time())
        self.path.write_text(json.dumps(self._d, indent=2))


class Trace:
    def __init__(self, workspace: Path):
        self.path = Path(workspace) / "trace.jsonl"

    def append(self, record: dict):
        record = dict(record)
        record["ts"] = time.time()
        with self.path.open("a") as f:
            f.write(json.dumps(record, ensure_ascii=False,
                               default=str) + "\n")

    def count(self) -> int:
        if not self.path.exists():
            return 0
        return sum(1 for line in self.path.read_text().splitlines()
                   if line.strip())


class Secret(str):
    """Text that computes normally but never appears in audit output.

    Certificates and traces record only `redacted()` — a marker plus a
    short SHA-256 prefix, enough for an auditor to confirm two runs used
    the same secret without ever seeing it. Redaction is per-value, not
    taint analysis: a string *derived* from a secret (concatenation,
    slicing) is plain text and is echoed like any other value.
    """
    __slots__ = ()

    def redacted(self) -> str:
        digest = hashlib.sha256(self.encode()).hexdigest()[:8]
        return f"<redacted:{digest}>"

    def __repr__(self) -> str:
        return self.redacted()


def redact_value(v):
    """Replace every Secret in a value tree with its redacted marker —
    the one door through which values enter certificates."""
    if isinstance(v, Secret):
        return v.redacted()
    if isinstance(v, list):
        return [redact_value(x) for x in v]
    if isinstance(v, dict):
        return {k: redact_value(x) for k, x in v.items()}
    return v


PARAM_TYPES = ("text", "num", "bool", "secret")


def resolve_params(table: list[dict], pairs: dict) -> dict:
    """Resolve CLI/embedding inputs against a program's param table.

    `table` rows: {"name", "type", "default", "required"} — the shape every
    backend compiler emits. `pairs` maps name -> raw value (strings from a
    command line; already-typed values from an embedding host). Raises
    ValueError with a user-facing message; nothing model-related has run
    by then, so refusal is free.
    """
    declared = {row["name"]: row for row in table}
    for name in pairs:
        if name not in declared:
            known = ", ".join(sorted(declared)) or "none"
            raise ValueError(
                f"unknown parameter {name!r} — this program declares: "
                f"{known}")
    out = {}
    for row in table:
        name, ptype = row["name"], row["type"]
        if name in pairs:
            out[name] = _coerce_param(name, ptype, pairs[name])
        elif row.get("required"):
            raise ValueError(
                f"required parameter {name!r} ({ptype}) was not given — "
                f"pass it as {name}=<value>")
        else:
            out[name] = row.get("default")
    return out


def _coerce_param(name: str, ptype: str, value):
    if ptype == "text":
        return value if isinstance(value, str) else str(value)
    if ptype == "secret":
        s = value if isinstance(value, str) else str(value)
        if s.startswith("env:"):
            var = s[4:]
            got = os.environ.get(var)
            if got is None:
                raise ValueError(
                    f"parameter {name!r}: environment variable {var!r} is "
                    f"not set — secret params accept {name}=env:VAR to "
                    "keep the value off the command line")
            s = got
        return Secret(s)
    if ptype == "num":
        if isinstance(value, bool):
            raise ValueError(f"parameter {name!r} expects a number")
        try:
            return float(value)
        except (TypeError, ValueError):
            raise ValueError(
                f"parameter {name!r} expects a number, got {value!r}") \
                from None
    if ptype == "bool":
        if isinstance(value, bool):
            return value
        v = str(value).strip().lower()
        if v in ("true", "1", "yes", "on"):
            return True
        if v in ("false", "0", "no", "off"):
            return False
        raise ValueError(
            f"parameter {name!r} expects true/false, got {value!r}")
    raise ValueError(f"parameter {name!r}: unknown type {ptype!r}")


def h(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:12]


def _b64(path) -> str:
    return base64.b64encode(Path(path).read_bytes()).decode()


def _image_mime(path) -> str:
    suffix = Path(path).suffix.lower()
    return {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".webp": "image/webp",
        ".gif": "image/gif",
    }.get(suffix, "application/octet-stream")


class Oracle:
    def __init__(self, timeout: int = 900):
        self.timeout = int(os.environ.get("KIMIYA_TIMEOUT", timeout))

    def models(self) -> list[str]:
        req = urllib.request.Request(BASE_URL + "/api/tags")
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        return [m["name"] for m in data.get("models", [])]

    def complete(self, agent: Agent, prompt: str, system: str = "",
                 temperature: float = 0.2, max_tokens: int = 1024,
                 images: list | None = None, schema: dict | None = None,
                 think: bool = False) -> str:
        if images and not agent.vision:
            raise RuntimeError(
                f"agent {agent.name} ({agent.model}) was given an image but "
                "is not vision-capable — it would answer about an image it "
                "never saw. Declare `vision = true` if it can in fact see.")
        if agent.backend == "ollama":
            return self._ollama(agent, prompt, system, temperature,
                                max_tokens, images)
        if agent.backend in ("openai", "openrouter"):
            return self._chat(agent, prompt, system, temperature,
                              max_tokens, images)
        if agent.backend == "anthropic":
            return self._anthropic(agent, prompt, system, max_tokens,
                                   images, schema, think)
        if agent.backend == "claude_cli":
            return self._claude_cli(agent, prompt, system, images)
        raise RuntimeError(f"unknown backend '{agent.backend}'")

    def _anthropic(self, agent, prompt, system, max_tokens, images,
                   schema, think):
        """The Anthropic API through the official SDK.

        Structured outputs are used whenever the caller supplies a schema,
        so a locate returns valid JSON by construction rather than by
        regex salvage. Thinking is requested only for judgments — a
        locate is a perception call, and the datasheet this instrument
        ships with was measured without it.
        """
        try:
            import anthropic
        except ImportError:
            raise RuntimeError(
                f"agent {agent.name}: backend 'anthropic' needs the SDK — "
                "`pip install anthropic`. It is the one optional "
                "dependency; the `claude_cli` backend needs nothing "
                "installed and no API key.") from None
        client = anthropic.Anthropic()
        content = []
        for p in images or []:
            content.append({"type": "image", "source": {
                "type": "base64", "media_type": _image_mime(p),
                "data": _b64(p)}})
        content.append({"type": "text", "text": prompt})
        kwargs = {"model": agent.model, "max_tokens": max_tokens,
                  "messages": [{"role": "user", "content": content}]}
        if system:
            kwargs["system"] = system
        if think:
            kwargs["thinking"] = {"type": "adaptive"}
        if schema:
            kwargs["output_config"] = {
                "format": {"type": "json_schema", "schema": schema}}
        msg = client.messages.create(**kwargs)
        if msg.stop_reason == "refusal":
            raise RuntimeError(
                f"agent {agent.name}: the request was declined "
                f"({getattr(msg.stop_details, 'category', None)})")
        return "".join(b.text for b in msg.content if b.type == "text")

    def _claude_cli(self, agent, prompt, system, images):
        """Headless Claude Code — no API key, no SDK, no dependency.

        The CLI reads the screenshot off disk itself (that is what
        `--allowedTools Read` is for), so images are passed by path
        rather than inlined. This is the same path the seenslide GUI
        harness measured its locator datasheet through, which is why an
        imported datasheet transfers to it.
        """
        exe = shutil.which("claude")
        if not exe:
            raise RuntimeError(
                f"agent {agent.name}: the `claude` CLI is not on PATH. "
                "Install Claude Code, or use backend = \"anthropic\" with "
                "ANTHROPIC_API_KEY set.")
        text = prompt
        if images:
            paths = "\n".join(str(p) for p in images)
            text = (f"Read the image file(s) below, then answer.\n{paths}\n\n"
                    + prompt)
        if system:
            text = system + "\n\n" + text
        cmd = [exe, "-p", text, "--allowedTools", "Read",
               "--output-format", "text", "--model", agent.model]
        try:
            out = subprocess.run(cmd, capture_output=True, text=True,
                                 timeout=self.timeout,
                                 cwd=tempfile.gettempdir())
        except subprocess.TimeoutExpired:
            raise RuntimeError(
                f"agent {agent.name}: claude CLI timed out after "
                f"{self.timeout}s") from None
        if out.returncode != 0:
            raise RuntimeError(
                f"agent {agent.name}: claude CLI failed: "
                f"{out.stderr.strip()[:200]}")
        return out.stdout or ""

    def _ollama(self, agent, prompt, system, temperature, max_tokens,
                images=None):
        payload = {"model": agent.model, "prompt": prompt,
                   "system": system, "stream": False,
                   "options": {"temperature": temperature,
                               "num_predict": max_tokens}}
        if images:
            payload["images"] = [_b64(p) for p in images]
        req = urllib.request.Request(
            agent.resolved_url + "/api/generate",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            data = json.loads(resp.read())
        return data.get("response", "")

    def _chat(self, agent, prompt, system, temperature, max_tokens,
              images=None):
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        if images:
            parts = [{"type": "text", "text": prompt}]
            for p in images:
                parts.append({"type": "image_url", "image_url": {
                    "url": f"data:{_image_mime(p)};base64,{_b64(p)}"}})
            messages.append({"role": "user", "content": parts})
        else:
            messages.append({"role": "user", "content": prompt})
        payload = {"model": agent.model, "messages": messages,
                   "temperature": temperature, "max_tokens": max_tokens}
        if agent.backend == "openrouter" and agent.zdr:
            payload["provider"] = {"zdr": True}
        headers = {"Content-Type": "application/json"}
        if agent.key_env or agent.key_file:
            key = _agent_api_key(agent)
            if not key:
                source = (f"environment variable {agent.key_env}"
                          if agent.key_env else f"credential file {agent.key_file}")
                raise RuntimeError(f"agent {agent.name}: {source} is empty")
            headers["Authorization"] = f"Bearer {key}"
        req = urllib.request.Request(
            agent.resolved_url + "/chat/completions",
            data=json.dumps(payload).encode(), headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 402, 403):
                raise ProviderRefusal(
                    f"PROVIDER REFUSED ({exc.code}): {agent.host} rejected "
                    "the account itself -- exhausted credit or failed "
                    "authentication. Retrying cannot help until the "
                    "account is fixed.") from None
            raise
        choices = data.get("choices") or []
        if not choices:
            return ""
        return (choices[0].get("message") or {}).get("content", "") or ""


def _agent_api_key(agent: Agent) -> str:
    """Load an API key without placing its value in source, traces, or errors.

    Credential files may contain a raw token, KEY=value / export KEY=value,
    or a small JSON object with an api_key, key, token, or named key_env
    member. This deliberately returns only the value and never logs it.
    """
    if agent.key_env:
        return os.environ.get(agent.key_env, "").strip()
    path = Path(agent.key_file).expanduser()
    try:
        text = path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise RuntimeError(
            f"agent {agent.name}: cannot read credential file {path}: "
            f"{exc.strerror or type(exc).__name__}") from None
    if not text:
        return ""
    if text.startswith("{"):
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            raise RuntimeError(
                f"agent {agent.name}: credential file {path} is invalid JSON"
            ) from None
        names = [agent.key_env, "OPENROUTER_API_KEY", "api_key", "key",
                 "token"]
        for name in names:
            if name and isinstance(data.get(name), str):
                return data[name].strip()
        raise RuntimeError(
            f"agent {agent.name}: credential file {path} has no recognized "
            "key field")
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" in line:
            name, value = line.split("=", 1)
            if not agent.key_env or name.strip() == agent.key_env:
                return value.strip().strip("\"'")
        elif len(text.splitlines()) == 1:
            return line
    return ""


class MockOracle(Oracle):
    """KIMIYA_MOCK=1: deterministic, offline. YES unless the claim text
    contains 'MOCKNO'; gen fills schema fields with plausible strings;
    locate returns one box placed deterministically from the query hash,
    so different descriptions land on different points."""

    def models(self) -> list[str]:
        return ["mock-llama:1b", "mock-qwen:1b", "mock-gemma:1b"]

    def complete(self, agent: Agent, prompt: str, system: str = "",
                 temperature: float = 0.2, max_tokens: int = 1024,
                 images: list | None = None, schema: dict | None = None,
                 think: bool = False) -> str:
        if "DOM LOCATE" in system:
            # Deterministic: the first candidate, or a stated miss.
            if "MOCKMISS" in prompt:
                return json.dumps({"picks": []})
            return json.dumps({"picks": [0]})
        if "LOCATE" in system:
            if "MOCKMISS" in prompt:
                return "[]"
            seed = int(h(prompt), 16)
            x0, y0 = 100 + seed % 200, 100 + (seed >> 12) % 100
            return json.dumps({"controls": [
                {"box": [x0, y0, x0 + 120, y0 + 40],
                 "label": "mock control", "confidence": 0.9}]})
        # Matches the judge system prompt loosely: its exact wording has
        # drifted before and silently turned every mock verdict into NO.
        if "exactly YES or NO" in system:
            return "NO" if "MOCKNO" in prompt else "YES"
        m = re.search(r"FIELDS: ([a-z_, ]+)", prompt)
        if m:
            fields = [f.strip() for f in m.group(1).split(",") if f.strip()]
            return json.dumps({f: f"mock {f}" for f in fields})
        return "mock text output"


def get_oracle() -> Oracle:
    if os.environ.get("KIMIYA_MOCK") == "1":
        return MockOracle()
    return Oracle()


@dataclass
class Pool:
    bindings: dict           # agent name -> Agent, insertion-ordered

    @property
    def agents(self) -> list[Agent]:
        return list(self.bindings.values())

    def agent(self, name: str) -> Agent:
        return self.bindings[name]

    def default_generator(self) -> Agent:
        return self.agents[0]

    def panel_for(self, generator: Agent, k: int,
                  names: list[str] | None) -> tuple[list[Agent], bool]:
        gen_fam = generator.family
        cand = ([self.bindings[n] for n in names] if names
                else self.agents)
        others = [a for a in cand if a.family != gen_fam]
        if others:
            return (others * ((k // len(others)) + 1))[:k], True
        if not cand:
            cand = [generator]
        return (cand * k)[:k], False


JUDGE_SYSTEM = (
    "You are a strict verifier. Check the claim against the evidence "
    "point by point, briefly. Then answer on a final line with exactly "
    "YES or NO. YES only if the evidence clearly supports the claim. "
    "If unsure, answer NO."
)


def judge_verdict(text: str) -> bool:
    """The last YES/NO the judge committed to, scanning from the end."""
    for line in reversed(str(text).strip().splitlines()):
        line = line.strip().upper().lstrip("*# ")
        if line.startswith("YES"):
            return True
        if line.startswith("NO"):
            return False
    return False
GEN_SYSTEM = (
    "You are a careful generation engine. Return ONLY a JSON object with "
    "exactly the requested fields, no prose, no markdown fences."
)


@dataclass
class Judgment:
    verdict: bool
    votes: int
    k: int
    certified: bool
    task: str
    record: dict = field(default_factory=dict)


def run_judge(pool: Pool, oracle: Oracle, trace: Trace, sheets: Datasheets,
              task: str, claim: str, evidence: str, generator: Agent,
              k: int, tau: float, purpose: str,
              panel_names: list[str] | None, paraphrases: int,
              images: list | None = None) -> Judgment:
    panel, certified = pool.panel_for(generator, k, panel_names)
    if images:
        base = (f"PURPOSE: {purpose}\n\nThe attached screenshot is the "
                f"evidence.\n{evidence[:2000]}\n\nCLAIM: {claim}\n\n"
                "Does the screenshot support the claim?")
    else:
        base = (f"PURPOSE: {purpose}\n\nEVIDENCE:\n{evidence[:6000]}\n\n"
                f"CLAIM: {claim}\n\nDoes the evidence support the claim?")
    variants = [base]
    if paraphrases > 1:
        variants.append(base.replace(
            "Does the evidence support the claim?",
            "Is the claim warranted by the evidence above?").replace(
            "Does the screenshot support the claim?",
            "Is the claim warranted by the screenshot above?"))
    votes, voters = 0, []
    for i, agent in enumerate(panel):
        p = variants[i % len(variants)]
        try:
            # A judgment needs room to verify before it answers: a vision
            # backend may think, and a text judge handed a checklist claim
            # cannot walk it in eight tokens -- strict verifiers told to
            # answer NO when unsure then answer NO because they were made
            # unsure. The verdict is the last YES/NO the judge commits to,
            # and it is the LAST thing generated, so the budget must
            # outlast the walkthrough: at 256 tokens, two panel families
            # asked "point by point" about a 3,000-character warrant were
            # both cut off mid-checklist on every vote of ten -- measured
            # at 400-600 tokens to reach their final line, which the
            # scanner then read as NO. A silenced judge is not a no vote.
            out = oracle.complete(agent, p, system=JUDGE_SYSTEM,
                                  temperature=0.1,
                                  max_tokens=2048 if images else 1024,
                                  images=images, think=bool(images))
            vote = judge_verdict(out)
            err = None
        except ProviderRefusal:
            raise
        except (OSError, RuntimeError) as e:
            vote, err = False, str(e)[:80]
        votes += int(vote)
        voters.append({"agent": agent.name, "model": agent.model,
                       "host": agent.host, "vote": vote,
                       **({"error": err} if err else {})})
    verdict = votes >= math.ceil(tau * k)
    rec = {"kind": "judge", "task": task, "purpose": purpose,
           "claim": claim[:300], "claim_hash": h(claim),
           "evidence_hash": h(evidence),
           **({"images": [str(p) for p in images]} if images else {}),
           "votes": votes, "k": k,
           "tau": tau, "verdict": verdict, "certified": certified,
           "panel": voters, "generator": generator.label(),
           "datasheet": sheets.get(task)}
    trace.append(rec)
    return Judgment(verdict, votes, k, certified, task, rec)


def run_gen(oracle: Oracle, trace: Trace, agent: Agent, prompt: str,
            schema_fields: list[str] | None, budget: int = 3,
            images: list | None = None):
    """schema_fields None => free text; else JSON with those fields."""
    who = agent.label()
    if schema_fields is None:
        try:
            out = oracle.complete(agent, prompt, temperature=0.3,
                                  images=images)
            trace.append({"kind": "gen", "agent": who,
                          "prompt_hash": h(prompt), "ok": True,
                          **({"images": [str(p) for p in images]}
                             if images else {})})
            return out.strip()
        except ProviderRefusal:
            raise
        except (OSError, RuntimeError) as e:
            trace.append({"kind": "gen", "agent": who,
                          "prompt_hash": h(prompt), "ok": False,
                          "error": str(e)[:80]})
            return None
    want = ", ".join(schema_fields)
    full = f"{prompt}\n\nFIELDS: {want}\nReturn ONLY a JSON object."
    # A wide schema cannot answer inside the default completion budget,
    # and reasoning models spend part of it thinking before the first
    # field. Scale the ceiling with the schema; unused headroom is free.
    # A floor, not a fit: a schema field is not a size. Two text fields
    # can carry a paragraph or a JSON object of twenty entries, and at
    # 512 tokens per field a two-field answer was cut off mid-JSON,
    # failed to parse, and exhausted its retries -- billed each time --
    # for want of room it was never given. max_tokens is a cap, not a
    # cost: generous is free when the answer is short.
    room = max(4096, 512 * len(schema_fields))
    for attempt in range(budget):
        try:
            out = oracle.complete(agent, full, system=GEN_SYSTEM,
                                  temperature=0.3 + 0.2 * attempt,
                                  max_tokens=room,
                                  images=images)
        except ProviderRefusal:
            raise
        except (OSError, RuntimeError) as e:
            trace.append({"kind": "gen", "agent": who, "attempt": attempt,
                          "prompt_hash": h(full), "ok": False,
                          "error": str(e)[:80]})
            continue
        text = re.sub(r"^```(json)?|```$", "", out.strip(), flags=re.M).strip()
        m = re.search(r"\{.*\}", text, flags=re.S)
        if not m:
            continue
        try:
            obj = json.loads(m.group(0))
        except json.JSONDecodeError:
            continue
        if all(f in obj for f in schema_fields):
            trace.append({"kind": "gen", "agent": who, "attempt": attempt,
                          "prompt_hash": h(full), "ok": True,
                          **({"images": [str(p) for p in images]}
                             if images else {})})
            return obj
    trace.append({"kind": "gen", "agent": who, "prompt_hash": h(full),
                  "ok": False, "budget_exhausted": True})
    return None
